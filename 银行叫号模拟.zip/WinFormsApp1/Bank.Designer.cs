﻿
namespace WinFormsApp1
{
    partial class Bank
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.next1 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.next2 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.next3 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.next4 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.next5 = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.wait = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.getnumber = new System.Windows.Forms.Button();
            this.tips = new System.Windows.Forms.Label();
            this.r1 = new System.Windows.Forms.Label();
            this.r2 = new System.Windows.Forms.Label();
            this.r3 = new System.Windows.Forms.Label();
            this.r4 = new System.Windows.Forms.Label();
            this.r5 = new System.Windows.Forms.Label();
            this.please = new System.Windows.Forms.Label();
            this.leave1 = new System.Windows.Forms.Button();
            this.leave2 = new System.Windows.Forms.Button();
            this.leave3 = new System.Windows.Forms.Button();
            this.leave4 = new System.Windows.Forms.Button();
            this.leave5 = new System.Windows.Forms.Button();
            this.leaves = new System.Windows.Forms.Label();
            this.get = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightCyan;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.next1);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Location = new System.Drawing.Point(53, 52);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(156, 68);
            this.panel1.TabIndex = 0;
            // 
            // next1
            // 
            this.next1.BackColor = System.Drawing.Color.PaleTurquoise;
            this.next1.Location = new System.Drawing.Point(31, 27);
            this.next1.Name = "next1";
            this.next1.Size = new System.Drawing.Size(94, 29);
            this.next1.TabIndex = 0;
            this.next1.Text = "下一个";
            this.next1.UseVisualStyleBackColor = false;
            this.next1.Click += new System.EventHandler(this.next1_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft YaHei UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(25, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 25);
            this.label4.TabIndex = 20;
            this.label4.Text = "办理窗口1";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LightCyan;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.next2);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Location = new System.Drawing.Point(237, 52);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(156, 68);
            this.panel2.TabIndex = 1;
            // 
            // next2
            // 
            this.next2.BackColor = System.Drawing.Color.PaleTurquoise;
            this.next2.Location = new System.Drawing.Point(29, 27);
            this.next2.Name = "next2";
            this.next2.Size = new System.Drawing.Size(94, 29);
            this.next2.TabIndex = 0;
            this.next2.Text = "下一个";
            this.next2.UseVisualStyleBackColor = false;
            this.next2.Click += new System.EventHandler(this.next2_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft YaHei UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(24, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(99, 25);
            this.label5.TabIndex = 20;
            this.label5.Text = "办理窗口2";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.LightCyan;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.next3);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Location = new System.Drawing.Point(431, 52);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(156, 68);
            this.panel3.TabIndex = 2;
            // 
            // next3
            // 
            this.next3.BackColor = System.Drawing.Color.PaleTurquoise;
            this.next3.Location = new System.Drawing.Point(30, 27);
            this.next3.Name = "next3";
            this.next3.Size = new System.Drawing.Size(94, 29);
            this.next3.TabIndex = 0;
            this.next3.Text = "下一个";
            this.next3.UseVisualStyleBackColor = false;
            this.next3.Click += new System.EventHandler(this.next3_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft YaHei UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(25, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(99, 25);
            this.label6.TabIndex = 20;
            this.label6.Text = "办理窗口3";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.LightCyan;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.next4);
            this.panel4.Controls.Add(this.label7);
            this.panel4.Location = new System.Drawing.Point(622, 52);
            this.panel4.Margin = new System.Windows.Forms.Padding(4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(156, 68);
            this.panel4.TabIndex = 3;
            // 
            // next4
            // 
            this.next4.BackColor = System.Drawing.Color.PaleTurquoise;
            this.next4.Location = new System.Drawing.Point(27, 27);
            this.next4.Name = "next4";
            this.next4.Size = new System.Drawing.Size(94, 29);
            this.next4.TabIndex = 0;
            this.next4.Text = "下一个";
            this.next4.UseVisualStyleBackColor = false;
            this.next4.Click += new System.EventHandler(this.next4_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft YaHei UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(22, -1);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(99, 25);
            this.label7.TabIndex = 20;
            this.label7.Text = "办理窗口4";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.LightCyan;
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.next5);
            this.panel5.Controls.Add(this.label8);
            this.panel5.Location = new System.Drawing.Point(820, 52);
            this.panel5.Margin = new System.Windows.Forms.Padding(4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(156, 68);
            this.panel5.TabIndex = 4;
            // 
            // next5
            // 
            this.next5.BackColor = System.Drawing.Color.PaleTurquoise;
            this.next5.Location = new System.Drawing.Point(31, 27);
            this.next5.Name = "next5";
            this.next5.Size = new System.Drawing.Size(94, 29);
            this.next5.TabIndex = 0;
            this.next5.Text = "下一个";
            this.next5.UseVisualStyleBackColor = false;
            this.next5.Click += new System.EventHandler(this.next5_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft YaHei UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(26, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(99, 25);
            this.label8.TabIndex = 20;
            this.label8.Text = "办理窗口4";
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.SkyBlue;
            this.label1.Font = new System.Drawing.Font("黑体", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(82, 11);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(870, 33);
            this.label1.TabIndex = 5;
            this.label1.Text = "业务办理服务区";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label1.UseWaitCursor = true;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label2.Location = new System.Drawing.Point(503, 432);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 42);
            this.label2.TabIndex = 6;
            this.label2.Text = "等待区";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.wait);
            this.panel6.Location = new System.Drawing.Point(340, 312);
            this.panel6.Margin = new System.Windows.Forms.Padding(4);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(404, 116);
            this.panel6.TabIndex = 12;
            // 
            // wait
            // 
            this.wait.AutoSize = true;
            this.wait.Font = new System.Drawing.Font("Microsoft YaHei UI", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.wait.Location = new System.Drawing.Point(58, 35);
            this.wait.Name = "wait";
            this.wait.Size = new System.Drawing.Size(274, 35);
            this.wait.TabIndex = 15;
            this.wait.Text = "当前的等候区人数：0";
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Aqua;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label3.Location = new System.Drawing.Point(39, 312);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(125, 42);
            this.label3.TabIndex = 13;
            this.label3.Text = "取号处：";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // getnumber
            // 
            this.getnumber.BackColor = System.Drawing.Color.PaleGreen;
            this.getnumber.Font = new System.Drawing.Font("幼圆", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.getnumber.ForeColor = System.Drawing.SystemColors.ControlText;
            this.getnumber.Location = new System.Drawing.Point(39, 377);
            this.getnumber.Margin = new System.Windows.Forms.Padding(4);
            this.getnumber.Name = "getnumber";
            this.getnumber.Size = new System.Drawing.Size(163, 61);
            this.getnumber.TabIndex = 14;
            this.getnumber.Text = "点击取号";
            this.getnumber.UseVisualStyleBackColor = false;
            this.getnumber.Click += new System.EventHandler(this.getnumber_Click);
            // 
            // tips
            // 
            this.tips.AutoSize = true;
            this.tips.Font = new System.Drawing.Font("Microsoft YaHei UI", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tips.Location = new System.Drawing.Point(702, 485);
            this.tips.Name = "tips";
            this.tips.Size = new System.Drawing.Size(274, 35);
            this.tips.TabIndex = 15;
            this.tips.Text = "提示：总接待人数：0";
            // 
            // r1
            // 
            this.r1.AutoSize = true;
            this.r1.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.r1.Location = new System.Drawing.Point(101, 141);
            this.r1.Name = "r1";
            this.r1.Size = new System.Drawing.Size(32, 27);
            this.r1.TabIndex = 16;
            this.r1.Text = "空";
            // 
            // r2
            // 
            this.r2.AutoSize = true;
            this.r2.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.r2.Location = new System.Drawing.Point(287, 141);
            this.r2.Name = "r2";
            this.r2.Size = new System.Drawing.Size(32, 27);
            this.r2.TabIndex = 16;
            this.r2.Text = "空";
            // 
            // r3
            // 
            this.r3.AutoSize = true;
            this.r3.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.r3.Location = new System.Drawing.Point(479, 141);
            this.r3.Name = "r3";
            this.r3.Size = new System.Drawing.Size(32, 27);
            this.r3.TabIndex = 16;
            this.r3.Text = "空";
            // 
            // r4
            // 
            this.r4.AutoSize = true;
            this.r4.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.r4.Location = new System.Drawing.Point(671, 141);
            this.r4.Name = "r4";
            this.r4.Size = new System.Drawing.Size(32, 27);
            this.r4.TabIndex = 16;
            this.r4.Text = "空";
            // 
            // r5
            // 
            this.r5.AutoSize = true;
            this.r5.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.r5.Location = new System.Drawing.Point(865, 141);
            this.r5.Name = "r5";
            this.r5.Size = new System.Drawing.Size(32, 27);
            this.r5.TabIndex = 16;
            this.r5.Text = "空";
            // 
            // please
            // 
            this.please.AutoSize = true;
            this.please.Font = new System.Drawing.Font("Microsoft YaHei UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.please.Location = new System.Drawing.Point(322, 215);
            this.please.Name = "please";
            this.please.Size = new System.Drawing.Size(413, 39);
            this.please.TabIndex = 17;
            this.please.Text = "请0号客户到0窗口办理业务！";
            // 
            // leave1
            // 
            this.leave1.Location = new System.Drawing.Point(22, 127);
            this.leave1.Name = "leave1";
            this.leave1.Size = new System.Drawing.Size(41, 58);
            this.leave1.TabIndex = 18;
            this.leave1.Text = "离开";
            this.leave1.UseVisualStyleBackColor = true;
            this.leave1.Click += new System.EventHandler(this.leave1_Click);
            // 
            // leave2
            // 
            this.leave2.Location = new System.Drawing.Point(218, 127);
            this.leave2.Name = "leave2";
            this.leave2.Size = new System.Drawing.Size(41, 58);
            this.leave2.TabIndex = 18;
            this.leave2.Text = "离开";
            this.leave2.UseVisualStyleBackColor = true;
            this.leave2.Click += new System.EventHandler(this.leave2_Click);
            // 
            // leave3
            // 
            this.leave3.Location = new System.Drawing.Point(411, 127);
            this.leave3.Name = "leave3";
            this.leave3.Size = new System.Drawing.Size(41, 58);
            this.leave3.TabIndex = 18;
            this.leave3.Text = "离开";
            this.leave3.UseVisualStyleBackColor = true;
            this.leave3.Click += new System.EventHandler(this.leave3_Click);
            // 
            // leave4
            // 
            this.leave4.Location = new System.Drawing.Point(601, 127);
            this.leave4.Name = "leave4";
            this.leave4.Size = new System.Drawing.Size(41, 58);
            this.leave4.TabIndex = 18;
            this.leave4.Text = "离开";
            this.leave4.UseVisualStyleBackColor = true;
            this.leave4.Click += new System.EventHandler(this.leave4_Click);
            // 
            // leave5
            // 
            this.leave5.Location = new System.Drawing.Point(803, 127);
            this.leave5.Name = "leave5";
            this.leave5.Size = new System.Drawing.Size(41, 58);
            this.leave5.TabIndex = 18;
            this.leave5.Text = "离开";
            this.leave5.UseVisualStyleBackColor = true;
            this.leave5.Click += new System.EventHandler(this.leave5_Click);
            // 
            // leaves
            // 
            this.leaves.AutoSize = true;
            this.leaves.Font = new System.Drawing.Font("Microsoft YaHei UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.leaves.Location = new System.Drawing.Point(756, 262);
            this.leaves.Name = "leaves";
            this.leaves.Size = new System.Drawing.Size(204, 32);
            this.leaves.TabIndex = 19;
            this.leaves.Text = "0号用户已离开。";
            // 
            // get
            // 
            this.get.AutoSize = true;
            this.get.Font = new System.Drawing.Font("Microsoft YaHei UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.get.Location = new System.Drawing.Point(39, 442);
            this.get.Name = "get";
            this.get.Size = new System.Drawing.Size(229, 32);
            this.get.TabIndex = 21;
            this.get.Text = "您当前的号码为：0";
            // 
            // timer1
            // 
            this.timer1.Interval = 3000;
            // 
            // Bank
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1030, 529);
            this.Controls.Add(this.get);
            this.Controls.Add(this.leaves);
            this.Controls.Add(this.leave5);
            this.Controls.Add(this.leave4);
            this.Controls.Add(this.leave3);
            this.Controls.Add(this.leave2);
            this.Controls.Add(this.leave1);
            this.Controls.Add(this.please);
            this.Controls.Add(this.r5);
            this.Controls.Add(this.r4);
            this.Controls.Add(this.r3);
            this.Controls.Add(this.r2);
            this.Controls.Add(this.r1);
            this.Controls.Add(this.tips);
            this.Controls.Add(this.getnumber);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Bank";
            this.Text = "银行叫号系统";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button getnumber;
        private System.Windows.Forms.Label tips;
        private System.Windows.Forms.Button next1;
        private System.Windows.Forms.Button next2;
        private System.Windows.Forms.Button next3;
        private System.Windows.Forms.Button next4;
        private System.Windows.Forms.Button next5;
        private System.Windows.Forms.Label r1;
        private System.Windows.Forms.Label r2;
        private System.Windows.Forms.Label r3;
        private System.Windows.Forms.Label r4;
        private System.Windows.Forms.Label r5;
        private System.Windows.Forms.Label please;
        private System.Windows.Forms.Label wait;
        private System.Windows.Forms.Button leave1;
        private System.Windows.Forms.Button leave2;
        private System.Windows.Forms.Button leave3;
        private System.Windows.Forms.Button leave4;
        private System.Windows.Forms.Button leave5;
        private System.Windows.Forms.Label leaves;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label get;
        private System.Windows.Forms.Timer timer1;
    }
}

